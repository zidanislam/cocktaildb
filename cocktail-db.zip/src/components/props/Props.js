import React, { useEffect, useState } from 'react';
import ChildProps from './ChildProps/ChildProps';

const Props = () => {
    const [cocktails, setCocktails] = useState([]);
  useEffect(() => {
    fetch("https://www.thecocktaildb.com/api/json/v1/1/search.php?s=")
      .then((res) => res.json())
      .then((data) => setCocktails(data.drinks));
  }, []);
    return (
        <div>
            <ChildProps demoProps={"demoprops"}/>
        </div>
    );
};

export default Props;